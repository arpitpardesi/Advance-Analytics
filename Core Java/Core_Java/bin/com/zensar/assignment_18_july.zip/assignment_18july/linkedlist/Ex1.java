package com.zensar.assignment_18july.linkedlist;

import java.util.LinkedList;


public class Ex1 {

	public static void main(String[] args) {
		LinkedList<String> listOfCities = new LinkedList<String>();
        listOfCities.add("Pune");
        listOfCities.add("Mumbai");
        listOfCities.add("Delhi");
        listOfCities.add("Indore");
        listOfCities.add("Mhow");

        System.out.println(listOfCities);
	}
}
