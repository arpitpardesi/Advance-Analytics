package com.zensar.assignment_18july.wrapper;

public class Ex2 {

	public static void main(String[] args) {
		Integer empID = 1234;
	    Double empSalary = 100000.99;
	    Character empRank = 'A';
	    System.out.println(empID.intValue());
	    System.out.println(empSalary.doubleValue());
	    System.out.println(empRank.charValue());
	}
}
