package com.zensar.assignment_18july.wrapper;

public class Ex1 {

	public static void main(String[] args) {
		Integer empID = 1234;
	    Double empSalary = 100000.99;
	    Character empRank = 'A';
	    System.out.println(empID);
	    System.out.println(empSalary);
	    System.out.println(empRank);
	}
}
