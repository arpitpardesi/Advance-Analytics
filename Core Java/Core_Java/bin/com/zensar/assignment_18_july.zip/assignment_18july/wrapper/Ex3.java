package com.zensar.assignment_18july.wrapper;

public class Ex3 {

	public static void main(String[] args) {
		Integer empID = 1234;
	    String ID = empID.toString();
	    System.out.println(ID);
	    System.out.println(empID);
	}
}
