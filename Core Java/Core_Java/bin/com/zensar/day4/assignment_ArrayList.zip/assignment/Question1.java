package com.zensar.day4.assignment;

import java.util.ArrayList;

public class Question1 {

	public static void main(String[] args) {
		ArrayList<String> color = new ArrayList<String>();
		
		color.add("Red");
		color.add("Green");
		color.add("Blue");
		
		System.out.println(color);
		
	}	
}
