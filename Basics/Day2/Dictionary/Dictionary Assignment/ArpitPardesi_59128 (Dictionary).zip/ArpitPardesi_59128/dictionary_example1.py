"""
Using keys and indexing, print the 'hello' from the following dictionary:
d1 = {'simple_key':'hello'}

"""
d1 = {'simple_key':'hello'}

print(d1.get("simple_key"))







