"""
Create dictionary of employees with empId as key and empName as value.
Create atleast 5 elements.
    Print all the keys and corresponding value from the dictionary.
            sample output:
            111 Brad
            412 John
            153 Ian
            714 Peter
            135 Smith


"""
dict_emp = {111:'Brad', 412:'John', 153:'Ian',714:'Peter', 135:'Smith'}

















