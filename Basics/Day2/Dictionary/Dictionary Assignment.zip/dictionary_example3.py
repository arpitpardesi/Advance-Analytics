"""
Using keys and indexing, print the 'hello' from the following dictionary:
d3 = {'k1':[{'nest_key':['this is deep',['hello']]}]}

"""
d3 = {'k1':[{'nest_key':['this is deep',['hello']]}]}









