"""
Using keys and indexing, print the 'hello' from the following dictionary:
d2 = {'k1':{'k2':'hello'}}

"""
d2 = {'k1':{'k2':'hello'}}


