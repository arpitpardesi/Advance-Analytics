# Use range() to print all the even
# numbers from 1 to 20.

for i in range(2,21,2):
    print(i)














