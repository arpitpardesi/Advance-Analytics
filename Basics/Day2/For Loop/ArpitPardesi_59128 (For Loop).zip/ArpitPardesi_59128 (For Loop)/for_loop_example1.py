# Write a program to add all the numbers of a list and print the result
list1 =[10, 20, 30, 40, 50]
sum = 0

for i in list1:
    sum = sum + i

print(sum)





























