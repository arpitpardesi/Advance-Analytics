# Print only the words that start with s in a given sentence

st = 'Print only the words that start with s in a given sentence'

for i in st.split(" "):
    if(i.startswith("s")):
        print(i)




