"""
Find out and print the vowels in a given word
word = 'Milliways'
vowels = ['a', 'e', 'i', 'o', 'u']
"""
word = 'Milliways'
vowels = ['a', 'e', 'i', 'o', 'u']
result=[]









