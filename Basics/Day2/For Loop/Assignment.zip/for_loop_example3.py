# Use range() to print all the even
# numbers from 1 to 20.
















