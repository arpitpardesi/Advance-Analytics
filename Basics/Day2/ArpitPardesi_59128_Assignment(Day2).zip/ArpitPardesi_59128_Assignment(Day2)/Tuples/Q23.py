def last(n):
    return n[m]

price = [('item1', '12.20'), ('item2', '15.10'), ('item3', '24.5')]
m=1
print(sorted(price, key=last))

