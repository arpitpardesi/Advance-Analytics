t = [(), (), ('',), ('a', 'b'), ('a', 'b', 'c'), ('d')]
t = [i for i in t if i]
print(t)