a = (2, 4, 5, 6, 2, 3, 4, 4, 7)
print(a.count(4)) 