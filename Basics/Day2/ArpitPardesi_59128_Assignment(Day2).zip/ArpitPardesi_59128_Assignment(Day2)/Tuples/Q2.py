a=(1,"a")
print(a)