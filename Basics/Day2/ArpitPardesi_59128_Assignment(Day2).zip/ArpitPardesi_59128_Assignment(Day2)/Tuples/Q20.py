t = ((2, "w"),(3, "r"))
print("This is tuple",t)