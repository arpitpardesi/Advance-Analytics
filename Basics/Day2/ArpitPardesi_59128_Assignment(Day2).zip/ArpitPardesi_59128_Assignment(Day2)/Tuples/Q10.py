a = (2, 4, 5, 6, 2, 3, 4, 4, 7)
if 4 in a:
    print("yes")