t=1,2,3
a,b,c = t
print(a,b,c)