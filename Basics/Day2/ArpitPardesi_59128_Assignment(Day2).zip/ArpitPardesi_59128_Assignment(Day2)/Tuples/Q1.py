a=()
print(type(a))