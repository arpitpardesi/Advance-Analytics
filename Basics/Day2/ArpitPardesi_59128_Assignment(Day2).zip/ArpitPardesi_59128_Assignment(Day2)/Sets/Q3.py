n = set([0, 1, 2, 3, 4])
print(n)
n.add(5)
print(n)