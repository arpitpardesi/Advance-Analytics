n = set([0, 1, 2, 3, 4])
m = n.copy()
print(m)