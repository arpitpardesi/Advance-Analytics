n = set([0, 1, 2, 3, 4])
print(n)
n.discard(1)
print(n)