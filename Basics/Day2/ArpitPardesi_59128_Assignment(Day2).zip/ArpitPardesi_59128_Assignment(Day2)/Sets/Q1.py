x = set()
print(x)
n = set([0, 1, 2, 3, 4])
print(n)