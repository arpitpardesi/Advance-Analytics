n = set([0, 1, 2, 3, 4])

print(len(n))