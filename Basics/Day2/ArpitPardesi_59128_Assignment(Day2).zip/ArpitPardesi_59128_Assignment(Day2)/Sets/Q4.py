n = set([0, 1, 2, 3, 4])
print(n)
n.remove(3)
print(n)