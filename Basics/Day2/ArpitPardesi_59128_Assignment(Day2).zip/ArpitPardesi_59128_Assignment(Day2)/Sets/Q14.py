n = set([0, 1, 2, 3, 4])
print(max(n))
print(min(n))