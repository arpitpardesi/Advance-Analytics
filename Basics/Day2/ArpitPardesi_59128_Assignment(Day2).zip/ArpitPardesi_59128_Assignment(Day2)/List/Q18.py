import itertools
a = [1,2,3]
a = list(itertools.permutations(a))
print(a)
