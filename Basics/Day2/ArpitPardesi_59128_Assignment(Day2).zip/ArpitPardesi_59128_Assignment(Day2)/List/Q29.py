a=[5,7,3,8,3,9,2,5,8,2,2,5,5]
a=set(a)
a=list(a)
print(a)