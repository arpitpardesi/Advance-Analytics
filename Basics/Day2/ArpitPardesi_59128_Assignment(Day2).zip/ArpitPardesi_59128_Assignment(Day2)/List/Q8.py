b = []

if(len(b)<1):
    print("empty")