import collections
a=[5,7,3,8,3,9,2,5,8,2,2,5,5]
print(a)

c = collections.Counter(a)
print(c)