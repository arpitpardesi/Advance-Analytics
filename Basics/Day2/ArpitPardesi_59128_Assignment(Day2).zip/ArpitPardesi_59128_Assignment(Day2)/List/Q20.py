a = [1,2,3,4,5,6]
for i in range(len(a)):
    print(i,a[i])