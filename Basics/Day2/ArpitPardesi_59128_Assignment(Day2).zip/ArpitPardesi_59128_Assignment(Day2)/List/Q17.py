l = []
for i in range(1,31):
    l.append(i**2)

print(l[5:])