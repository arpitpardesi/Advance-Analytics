a = [1,2,3,4,5,6,7,8,9]
c=0
min,max = 1,8
for i in a:
    if(min <= i <= max):
        c=c+1
print(c)