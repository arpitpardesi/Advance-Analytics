a = [[ ['*' for k in range(6)] for j in range(4)] for i in range(3)]
print(a)
