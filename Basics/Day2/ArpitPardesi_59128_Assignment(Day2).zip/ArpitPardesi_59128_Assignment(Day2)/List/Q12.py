a = ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']
del a[5]
del a[4]
del a[0]
print(a)