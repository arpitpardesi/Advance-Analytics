a = ['a','r','p','i','t']
b = ''.join(a)
print(b) 