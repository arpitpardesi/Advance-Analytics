a = [1,2,3,4,5,6]
b = [2,6,4,3,7,9]
print(' '.join(map(str, b)) in ' '.join(map(str, a * 2)))