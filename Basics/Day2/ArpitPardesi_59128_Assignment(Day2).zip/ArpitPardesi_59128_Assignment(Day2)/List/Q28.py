a=[5,7,3,8,3,9,2]
a=sorted(a)
print(a[-2])