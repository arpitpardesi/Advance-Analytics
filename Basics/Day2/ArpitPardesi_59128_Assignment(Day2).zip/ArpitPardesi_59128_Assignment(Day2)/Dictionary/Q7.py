a = {} 
for i in range(1,16):
    a[i] = i**2
print(a)