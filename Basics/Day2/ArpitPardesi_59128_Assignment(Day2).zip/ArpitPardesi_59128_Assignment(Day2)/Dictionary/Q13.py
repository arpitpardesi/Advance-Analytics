keys = [1,2,3,4]
values = ["one","two","three","four"]
d = dict(zip(keys, values))
print(d)