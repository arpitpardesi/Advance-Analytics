a = a = {2: 'two',4: 'four', 1: 'one',  3: 'three'}

for key in sorted(a):
    print(key, a[key])