a = {
    1:"A",
    2:"b"
}
print(a)
a[3] = 'b'
print(a)