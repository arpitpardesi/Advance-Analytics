a = {'a': 100, 'b': 200}
b = {'x': 300, 'y': 200}
d = a.copy()
d.update(b)
print(d)