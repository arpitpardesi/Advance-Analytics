d ={'1':['a','b'], '2':['c','d']}
for i in d.get('1'):
    for j in d.get('2'):
         print(i,j)