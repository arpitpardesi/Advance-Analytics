a = {} 
n = 6
for i in range(6):
    a[i] = i**i
print(a)