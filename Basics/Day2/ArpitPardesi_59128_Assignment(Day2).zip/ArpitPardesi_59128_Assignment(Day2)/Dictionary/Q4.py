d = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
key = 3
if(key in d):
    print("Yes")
else:
    print("No")