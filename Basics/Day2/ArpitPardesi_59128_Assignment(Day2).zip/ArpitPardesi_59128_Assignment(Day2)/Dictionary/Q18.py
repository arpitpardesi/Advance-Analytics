a={}
if not bool(a):
    print("Empty")