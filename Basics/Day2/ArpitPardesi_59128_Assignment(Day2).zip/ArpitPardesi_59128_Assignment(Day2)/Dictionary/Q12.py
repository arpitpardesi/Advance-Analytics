d = {'a':1,'b':2,'c':3,'d':4}
print(d)
if 'a' in d: 
    del d['a']
print(d)