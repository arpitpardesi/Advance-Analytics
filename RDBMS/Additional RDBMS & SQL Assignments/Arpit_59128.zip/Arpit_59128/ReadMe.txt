Set 3 - ERD not done and q3 remaining

Set 10 - Tried documentation but not completed this set 

